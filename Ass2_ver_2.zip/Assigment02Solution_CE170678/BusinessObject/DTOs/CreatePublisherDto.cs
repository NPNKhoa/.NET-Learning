﻿namespace BusinessObject.DTOs
{
    public class CreatePublisherDto
    {
        public string publisher_name { get; set; }
        public string city { get; set; }
        public string state { get; set; }
        public string country { get; set; }

    }
}

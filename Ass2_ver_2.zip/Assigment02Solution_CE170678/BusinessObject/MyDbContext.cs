﻿using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;

namespace BusinessObject
{
    public class MyDbContext : DbContext
    {

        public MyDbContext() { }


        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)

        {

            var builder = new ConfigurationBuilder().SetBasePath(Directory.GetCurrentDirectory())
                .AddJsonFile("appsettings.json", optional: true, reloadOnChange: true);

            IConfigurationRoot configuration = builder.Build();

            optionsBuilder.UseSqlServer(configuration.GetConnectionString("Duyen"));

        }

        public virtual DbSet<Author> Authors { get; set; }
        public virtual DbSet<Book> Books { get; set; }
        public virtual DbSet<BookAuthor> BookAuthors { get; set; }
        public virtual DbSet<Publisher> Publishers { get; set; }
        public virtual DbSet<Role> Roles { get; set; }
        public virtual DbSet<User> Users { get; set; }


        protected override void OnModelCreating(ModelBuilder optionsBuilder)
        {
            base.OnModelCreating(optionsBuilder);
            optionsBuilder.Entity<BookAuthor>()
                .HasKey(p => new { p.author_id, p.book_id });

            optionsBuilder.Entity<BookAuthor>()
                .HasOne(p => p.Author)
                .WithMany(p => p.BookAuthors)
                .HasForeignKey(p => p.author_id);

            optionsBuilder.Entity<BookAuthor>()
                .HasOne(p => p.Book)
                .WithMany(p => p.BookAuthors)
                .HasForeignKey(p => p.book_id);

            List<Role> roles = new List<Role>()
            {
                new Role() {
                   role_id = 1,
                   role_desc="admin"
                },
                new Role() {
                   role_id = 2,
                   role_desc="user"
                }
            };

            optionsBuilder.Entity<Role>()
                .HasData(roles);

            //        optionsBuilder.Entity<Category>().HasData(
            //                new Category { CategoryId = 1, CategoryName = "Beverages" },
            //                new Category { CategoryId = 2, CategoryName = "Condiments" },
            //                new Category { CategoryId = 3, CategoryName = "Confections" },
            //                new Category { CategoryId = 4, CategoryName = "Grains/Cereals" },
            //                new Category { CategoryId = 5, CategoryName = "Dairy Products" },
            //                new Category { CategoryId = 6, CategoryName = "Heat/Poultry" },
            //                new Category { CategoryId = 7, CategoryName = "Produce" },
            //                new Category { CategoryId = 8, CategoryName = "Seafood" }
            //);
        }
    }
}

